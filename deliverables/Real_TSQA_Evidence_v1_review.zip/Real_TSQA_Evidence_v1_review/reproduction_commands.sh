#!/usr/bin/env bash
set -euo pipefail
# Replace CUDA_DEVICE only after checking host GPU ownership.
python scripts/extract_real_tsqa_reps.py --model-key qwen3_8b_base --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key qwen3_8b_base --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key qwen3_8b_base --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key qwen3_8b_base --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key qwen3_8b_base --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key qwen3_8b_base --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key qwen3_8b_base --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key qwen3_8b_base --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key qwen3_8b_base --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key qwen3_8b_base --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key qwen3_8b_base --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama31_8b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key llama31_8b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key llama31_8b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama31_8b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama31_8b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama31_8b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama31_8b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama31_8b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama31_8b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama31_8b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama31_8b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama32_3b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key llama32_3b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key llama32_3b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama32_3b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama32_3b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama32_3b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama32_3b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama32_3b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key llama32_3b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key llama32_3b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key llama32_3b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_9b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key gemma2_9b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key gemma2_9b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_9b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_9b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_9b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_9b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_9b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_9b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_9b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_9b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_2b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key gemma2_2b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key gemma2_2b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_2b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_2b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_2b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_2b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_2b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key gemma2_2b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key gemma2_2b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key gemma2_2b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key mistral_7b_v03 --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key mistral_7b_v03 --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key mistral_7b_v03 --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key mistral_7b_v03 --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key mistral_7b_v03 --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key mistral_7b_v03 --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key mistral_7b_v03 --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key mistral_7b_v03 --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key mistral_7b_v03 --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key mistral_7b_v03 --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key mistral_7b_v03 --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_llm_7b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key deepseek_llm_7b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key deepseek_llm_7b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_llm_7b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_llm_7b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_llm_7b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_llm_7b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_llm_7b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_llm_7b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_llm_7b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_llm_7b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_v2_lite --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key deepseek_v2_lite --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key deepseek_v2_lite --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_v2_lite --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_v2_lite --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_v2_lite --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_v2_lite --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_v2_lite --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key deepseek_v2_lite --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key deepseek_v2_lite --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key deepseek_v2_lite --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_7b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key olmo2_7b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key olmo2_7b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_7b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_7b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_7b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_7b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_7b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_7b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_7b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_7b --seed 27 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_13b --branch question --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key olmo2_13b --branch temporal --init pretrained --seed 7 --device CUDA_DEVICE
python scripts/extract_real_tsqa_reps.py --model-key olmo2_13b --branch temporal --init random --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_13b --seed 7 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_13b --seed 7 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_13b --branch temporal --init random --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_13b --seed 17 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_13b --seed 17 --device cpu
python scripts/extract_real_tsqa_reps.py --model-key olmo2_13b --branch temporal --init random --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_readout.py --model-key olmo2_13b --seed 27 --device CUDA_DEVICE
python scripts/run_real_tsqa_supervised.py --model-key olmo2_13b --seed 27 --device cpu
python scripts/run_real_tsqa_native.py --model-key qwen3_8b_base --mode free --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key qwen3_8b_base --mode constrained --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key llama31_8b --mode free --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key llama31_8b --mode constrained --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key gemma2_9b --mode free --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key gemma2_9b --mode constrained --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key deepseek_v2_lite --mode free --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key deepseek_v2_lite --mode constrained --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key olmo2_7b --mode free --device CUDA_DEVICE
python scripts/run_real_tsqa_native.py --model-key olmo2_7b --mode constrained --device CUDA_DEVICE
